// Scalable for Problem 4
public interface Scalable {
    void scale(double factor);
}