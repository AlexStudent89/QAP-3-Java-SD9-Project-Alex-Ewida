public interface Scalable {
    void scale(double scaleFactor);
}
