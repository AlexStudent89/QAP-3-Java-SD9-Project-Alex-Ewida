// Demo java file for Problem 2
public class Demo {
    public static void main(String[] args) {
        Point point = new Point(1.5f, 2.5f);
        System.out.println(point);

        MovablePoint movablePoint = new MovablePoint(1.5f, 2.5f, 1.0f, 1.0f);
        System.out.println(movablePoint);
        movablePoint.move();
        System.out.println("After moving: " + movablePoint);
    }
}