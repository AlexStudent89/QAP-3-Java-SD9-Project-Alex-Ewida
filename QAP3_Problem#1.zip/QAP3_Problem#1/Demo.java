// Demo for Problem 1
public class Demo {
    public static void main(String[] args) {
        Person bob = new Person("Jack Frost", 26, "M");
        System.out.println(bob);

        Student lynne = new Student("Sakura Peach", 17, "F", "GB95823", 3.6);
        System.out.println(lynne);

        Teacher mrJava = new Teacher("Dennis Wilson", 30, "M", "Project Management", 51000);
        System.out.println(mrJava);

        CollegeStudent ima = new CollegeStudent("Carol Danvers", 19, "F", "UCB123", 3.9, 1, "French");
        System.out.println(ima);
    }
}